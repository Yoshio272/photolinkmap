/**
 * image-proxy.ts - 360度画像CORSプロキシ
 * Google Drive / Box 両対応
 */
import type { Handler } from '@netlify/functions'

const ALLOWED_DOMAINS = [
  'lh3.googleusercontent.com',
  'dl.boxcloud.com',       // Box CDN（実画像）
  'api.box.com',           // Box API
  'public.boxcloud.com',   // Box公開CDN
  'drive.google.com',
  'storage.googleapis.com',
  // NOTE: app.box.com は除外（HTMLページを返すため画像プロキシ対象外）
  // ただし totalkakyo.box.com 等の shared/static は実画像を返すので許可
]

/** shared/static パスを持つ *.box.com は実画像なので許可 */
function isBoxSharedStatic(u: URL): boolean {
  return u.hostname.endsWith('.box.com') && u.pathname.startsWith('/shared/static/')
}

export const handler: Handler = async (event) => {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: cors, body: '' }

  const p = event.queryStringParameters ?? {}

  // ===== Box: トークン認証ダウンロード =====
  if (p.provider === 'box' && p.fileId && p.token) {
    try {
      const res = await fetch(`https://api.box.com/2.0/files/${p.fileId}/content`, {
        headers: { Authorization: `Bearer ${p.token}` },
        redirect: 'follow',
      })
      if (!res.ok) return { statusCode: res.status, headers: cors, body: `Box error: ${res.status}` }
      const ct = res.headers.get('content-type') ?? 'image/jpeg'
      const b64 = Buffer.from(await res.arrayBuffer()).toString('base64')
      return { statusCode: 200, headers: { ...cors, 'Content-Type': ct, 'Cache-Control': 'private, max-age=3600' }, body: b64, isBase64Encoded: true }
    } catch { return { statusCode: 502, headers: cors, body: 'Box fetch failed' } }
  }

  // ===== URL経由プロキシ =====
  const rawUrl = p.url
  if (!rawUrl) return { statusCode: 400, headers: cors, body: 'url parameter required' }

  let targetUrl: string
  try {
    targetUrl = decodeURIComponent(rawUrl)
    const u = new URL(targetUrl)
    const domainOk = ALLOWED_DOMAINS.some(d => u.hostname === d || u.hostname.endsWith('.' + d)) || isBoxSharedStatic(u)
    if (!domainOk) {
      return { statusCode: 403, headers: { ...cors, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: `Domain not allowed: ${u.hostname}. Use fileId-based access for Box files.` }) }
    }
    // app.box.com のHTML閲覧ページは明示的に拒否
    if (u.hostname === 'app.box.com' && u.pathname.startsWith('/file/')) {
      return { statusCode: 400, headers: { ...cors, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'app.box.com/file/ はHTMLページです。?provider=box&fileId=xxx&token=xxx を使用してください。' }) }
    }
  } catch { return { statusCode: 400, headers: cors, body: 'Invalid URL' } }

  try {
    const res = await fetch(targetUrl, {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; PhotoLinkMap/1.0)' },
      redirect: 'follow',
    })
    if (!res.ok) return { statusCode: res.status, headers: cors, body: `Upstream error: ${res.status}` }
    const ct = res.headers.get('content-type') ?? 'image/jpeg'
    if (ct.includes('text/html')) {
      return { statusCode: 403, headers: cors, body: 'HTML returned - check sharing settings' }
    }
    const b64 = Buffer.from(await res.arrayBuffer()).toString('base64')
    return { statusCode: 200, headers: { ...cors, 'Content-Type': ct, 'Cache-Control': 'public, max-age=3600' }, body: b64, isBase64Encoded: true }
  } catch { return { statusCode: 502, headers: cors, body: 'Failed to fetch image' } }
}
